This package is for formatting logs as JSON.  

To build run `python setup.py sdist`.  

When changing the code, please update the version in `setup.py` and the default version in the bash `distribute_tar_to_services.sh` script. Then run the script to distribute the tar ball to the listed services in the script (update if necessary) to make the new version installable.  
